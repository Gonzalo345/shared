<?php

require('../../config.php');
require_once($CFG->libdir.'/adminlib.php');
require_once('lib.php');

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('createnewsitem', 'local_newsletter'));
echo 'Hola estas son las news<h1></h2>';
echo $OUTPUT->footer();

?>