<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Functions for block Soporte e-ABC.
 *
 * @package    block_soporteeabc
 * @copyright  2017 e-ABC Learning
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

function soporteeabc_cron()
{
    global $CFG, $DB;

    //size files
    $sql = 'select distinct contenthash, filesize from {files}';
    $files = $DB->get_records_sql($sql, null, 0, 0);
    $peso = 0;

    foreach ($files as $file) {
        $peso = $peso + $file->filesize;
    }

    if ($peso >= 1024 && $peso < 1048576) {
        $peso = round($peso / 1024, 1) . 'B';
    }
    if ($peso >= 1048576 && $peso < 1073741824) {
        $peso = round($peso / 1048576, 1) . 'MB';
    }
    if ($peso >= 1073741824) {
        $peso = round($peso / 1073741824, 1) . 'GB';
    }

    $pesoarchivosobj = $DB->get_record('config_plugins', array('plugin' => 'block_soporteeabc', 'name' => 'eabcpesoarchivos'));
    if (!$pesoarchivosobj) {
        $pesoarchivosobj = new stdclass();
        $pesoarchivosobj->plugin = 'block_soporteeabc';
        $pesoarchivosobj->name = 'eabcpesoarchivos';
        $pesoarchivosobj->value = $peso;
        $insert = $DB->insert_record('config_plugins', $pesoarchivosobj, true);
    } else {
        $pesoarchivosobj->value = $peso;
        $DB->update_record('config_plugins', $pesoarchivosobj);
    }


    //size backup files
    $sql = "select distinct contenthash, filesize from {files} where mimetype like 'application/vnd.moodle.backup'";
    $files_bkp = $DB->get_records_sql($sql, null, 0, 0);
    $peso_bkp = 0;

    foreach ($files_bkp as $file_bkp) {
        $peso_bkp = $peso_bkp + $file_bkp->filesize;
    }

    if ($peso_bkp >= 1024 && $peso_bkp < 1048576) {
        $peso_bkp = round($peso_bkp / 1024, 1) . 'B';
    }
    if ($peso_bkp >= 1048576 && $peso_bkp < 1073741824) {
        $peso_bkp = round($peso_bkp / 1048576, 1) . 'MB';
    }
    if ($peso_bkp >= 1073741824) {
        $peso_bkp = round($peso_bkp / 1073741824, 1) . 'GB';
    }

    $eabcpesobackupsobj = $DB->get_record('config_plugins', array('plugin' => 'block_soporteeabc', 'name' => 'eabcpesobackups'));
    if (!$eabcpesobackupsobj) {
        $eabcpesobackupsobj = new stdclass();
        $eabcpesobackupsobj->plugin = 'block_soporteeabc';
        $eabcpesobackupsobj->name = 'eabcpesobackups';
        $eabcpesobackupsobj->value = $peso_bkp;
        $insert = $DB->insert_record('config_plugins', $eabcpesobackupsobj, true);
    } else {
        $eabcpesobackupsobj->value = $peso_bkp;
        $DB->update_record('config_plugins', $eabcpesobackupsobj);
    }

    //size repository files
    $command = 'du -sbh ' . $CFG->dataroot . '/repository';
    $op = shell_exec($command);
    if ($op == NULL) {
        $peso_bkp = '0MB';
    } else {
        $peso = explode("	", $op);
        $peso_bkp = $peso[0];
    }

    $eabcpesorepoobj = $DB->get_record('config_plugins', array('plugin' => 'block_soporteeabc', 'name' => 'eabcpesorepository'));
    if (!$eabcpesorepoobj) {
        $eabcpesorepoobj = new stdclass();
        $eabcpesorepoobj->plugin = 'block_soporteeabc';
        $eabcpesorepoobj->name = 'eabcpesorepository';
        $eabcpesorepoobj->value = $peso_bkp;
        $insert = $DB->insert_record('config_plugins', $eabcpesorepoobj, true);
    } else {
        $eabcpesorepoobj->value = $peso_bkp;
        $DB->update_record('config_plugins', $eabcpesorepoobj);
    }

    //size moodledata files
    $commandmdata = 'du -sbh ' . $CFG->dataroot;
    $opmdata = shell_exec($commandmdata);
    if ($opmdata == NULL) {
        $peso_bkp = '0MB';
    } else {
        $pesomdata = explode("	", $opmdata);
        $peso_bkp = $pesomdata[0];
    }


    $eabcpesomdataobj = $DB->get_record('config_plugins', array('plugin' => 'block_soporteeabc', 'name' => 'eabcpesomoodledata'));
    if (!$eabcpesomdataobj) {
        $eabcpesomdataobj = new stdclass();
        $eabcpesomdataobj->plugin = 'block_soporteeabc';
        $eabcpesomdataobj->name = 'eabcpesomoodledata';
        $eabcpesomdataobj->value = $peso_bkp;
        $insert = $DB->insert_record('config_plugins', $eabcpesomdataobj, true);
    } else {
        $eabcpesomdataobj->value = $peso_bkp;
        $DB->update_record('config_plugins', $eabcpesomdataobj);
    }

    //size database
    $sql = "SELECT SUM(data_length + index_length) as data FROM information_schema.tables where TABLE_SCHEMA = :tabla";
    $dbsize = $DB->get_record_sql($sql,['tabla'=>$CFG->dbname]);
    $dbdata = 0;
    if(isset($dbsize->data)){
        $dbdata = $dbsize->data;
    }else{
        $dbpeso = "0B";
    }

    if ($dbdata >= 1024 && $dbdata < 1048576) {
        $dbpeso = round($dbdata / 1024, 1) . 'KB';
    }
    if ($dbdata >= 1048576 && $dbdata < 1073741824) {
        $dbpeso = round($dbdata / 1048576, 1) . 'MB';
    }
    if ($dbdata >= 1073741824) {
        $dbpeso = round($dbdata / 1073741824, 1) . 'GB';
    }

    $eabcpesomdataobj = $DB->get_record('config_plugins', array('plugin' => 'block_soporteeabc', 'name' => 'eabcpesobasedatos'));
    if (!$eabcpesomdataobj) {
        $eabcpesomdataobj = new stdclass();
        $eabcpesomdataobj->plugin = 'block_soporteeabc';
        $eabcpesomdataobj->name = 'eabcpesobasedatos';
        $eabcpesomdataobj->value = $dbpeso;
        $insert = $DB->insert_record('config_plugins', $eabcpesomdataobj, true);
    } else {
        $eabcpesomdataobj->value = $dbpeso;
        $DB->update_record('config_plugins', $eabcpesomdataobj);
    }


}
