#blocks/soporteeabc

solo pueden verlo los usuarios que tengan el permiso "ver bloque soporteeabc" a nivel global (system)

permite: 
- Ver peso de archivos en general de la plataforma. 
- Ver peso de archivos de backup de la plataforma. 
- Link al formulario de creación de tickets del sistema de soporte con precompletado
  de campos nombre, email y url de plataforma.


#MOODLE_32

Compatible con moodle 3.2

El calculo de peso en disco se realiza ahora con una tarea programable 

#MOODLE_31

Se agregó tag MOODLE_31 indicando compatibilidad con moodle 3.1

#MOODLE_30

Se agregó tag MOODLE_31 indicando compatibilidad con moodle 3.0
