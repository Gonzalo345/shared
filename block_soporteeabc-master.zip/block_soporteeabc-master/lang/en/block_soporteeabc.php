<?php

$string['pluginname'] = 'Soporte e-ABC';
$string['soporteeabc'] = 'Soporte e-ABC';
$string['soporteeabc:addinstance'] = 'Add a new Soporte e-ABC block';
$string['soporteeabc:myaddinstance'] = 'Add a new Soporte e-ABC block to the My Moodle page';
$string['soporteeabc:ver'] = 'view soporteeabc block';
$string['totalsize'] = 'Total weight of files uploaded to the platform:';
$string['totalsizebkp'] = 'Total weight of backup files on the platform:';
$string['totalsizerepo'] = 'Total weight of repository folder:';
$string['totalsizemdata'] = 'Total weight of moodledata folder:';
$string['totalsizedatabase'] = 'Total weight of moodle database:';
$string['support'] = 'in the support system e-ABC platform administrators.';
$string['crontask'] = 'Cron task for Block Soporte e-ABC.';
$string['nodatatoshow'] = 'No data to show';
//$string['support'] = 'en el sistema de Soporte de e-ABC a administradores de la plataforma.';
//$string['totalsize'] = 'Peso total de archivos subidos a la plataforma:';

?>
