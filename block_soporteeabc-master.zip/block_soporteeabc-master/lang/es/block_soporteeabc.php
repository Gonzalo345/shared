<?php

$string['pluginname'] = 'Soporte e-ABC';
$string['soporteeabc'] = 'Soporte e-ABC';
$string['soporteeabc:addinstance'] = 'Agregar un nuevo bloque Soporte e-ABC';
$string['soporteeabc:myaddinstance'] = 'Agregar un nuevo bloque Soporte e-ABC block a la pagina de My moodle';
$string['soporteeabc:ver'] = 'ver bloque soporteeabc';
$string['support'] = 'en el sistema de Soporte de e-ABC a administradores de la plataforma.';
$string['totalsize'] = 'Peso total de archivos utilizados en la plataforma:';
$string['totalsizebkp'] = 'Peso de archivos de backups incluidos:';
$string['totalsizerepo'] = 'Peso total de la carpeta repository:';
$string['totalsizemdata'] = 'Peso total de la carpeta moodledata:';
$string['totalsizedatabase'] = 'Peso total de la base de datos de Moodle:';
$string['crontask'] = 'Tarea programada para bloque Soporte e-ABC';
$string['nodatatoshow'] = 'Sin datos para mostrar';

?>
