<?php
global $CFG;
require_once($CFG->dirroot.'/blocks/soporteeabc/lib.php');
class block_soporteeabc extends block_base {

    public function init() {
        $this->title = get_string('soporteeabc', 'block_soporteeabc');
        //$this->instance->visible = 0;
    }
    // The PHP tag and the curly bracket for the class definition
    // will only be closed after there is another function added in the next section.

    public function get_content() {
    global $DB;
    global $CFG;
    global $USER;
    $peso_mdata = "";
    $peso_repo = "";
    if ($this->content !== null) {
      return $this->content;
    }

    $peso = get_string('nodatatoshow', 'block_soporteeabc');
    $peso_bkp = get_string('nodatatoshow', 'block_soporteeabc');
    $pesoarchivos = $DB->get_record('config_plugins' , array('plugin'=>'block_soporteeabc','name'=>'eabcpesoarchivos'));
    $pesobackups = $DB->get_record('config_plugins' , array('plugin'=>'block_soporteeabc','name'=>'eabcpesobackups'));
    $pesorepository = $DB->get_record('config_plugins' , array('plugin'=>'block_soporteeabc','name'=>'eabcpesorepository'));
    $pesomdata = $DB->get_record('config_plugins' , array('plugin'=>'block_soporteeabc','name'=>'eabcpesomoodledata'));
    $pesobd = $DB->get_record('config_plugins' , array('plugin'=>'block_soporteeabc','name'=>'eabcpesobasedatos'));

    if($pesoarchivos){
        $peso = $pesoarchivos->value;
    }
    if($pesobackups){
        $peso_bkp = $pesobackups->value;
    }
    if($pesorepository){
        $peso_repo = $pesorepository->value;
    }
    if($pesomdata){
        $peso_mdata = $pesomdata->value;
    }
    if($pesobd){
        $peso_bd = $pesobd->value;
    }

    $site = $DB->get_record('course',array('id'=>1));
    $plataforma = $site->shortname;
    $this->content        =  new stdClass;

    $this->content->text  = '<center><p>'.get_string('totalsize', 'block_soporteeabc').'</p><p style="text-align:center;font-size:20px">';
    $this->content->text .=  $peso;
    $this->content->text .= '</p><hr /><br />';

    $this->content->text .= '<center><p>'.get_string('totalsizebkp', 'block_soporteeabc').'</p><p style="text-align:center;font-size:20px">';
    $this->content->text .=  $peso_bkp;
    $this->content->text .= '</p><hr /><br />';

    $this->content->text .= '<center><p>'.get_string('totalsizerepo', 'block_soporteeabc').'</p><p style="text-align:center;font-size:20px">';
    $this->content->text .=  $peso_repo;
    $this->content->text .= '</p><hr /><br />';

    $this->content->text .= '<center><p>'.get_string('totalsizemdata', 'block_soporteeabc').'</p><p style="text-align:center;font-size:20px">';
    $this->content->text .=  $peso_mdata;
    $this->content->text .= '</p><hr /><br />';

    $this->content->text .= '<center><p>'.get_string('totalsizedatabase', 'block_soporteeabc').'</p><p style="text-align:center;font-size:20px">';
    $this->content->text .=  $peso_bd;
    $this->content->text .= '</p><hr /><br />';

    $url = urlencode($CFG->wwwroot);
    $this->content->text .= '<p><a id="IMG_Soporte_e-ABC" href="http://clientes.e-abclearning.com" target="_blank"><img alt="Soporte e-ABC" src="/blocks/soporteeabc/img/new_ticket_title.jpg" height="50" width="160" /></a></p><p>'.get_string('support', 'block_soporteeabc').'</p></center>';

    if(!has_capability('block/soporteeabc:ver', context_system::instance())){
        $this->content = '';
    }
    return $this->content;
  }


}   // Here's the closing bracket for the class definition



?>
