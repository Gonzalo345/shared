<?php

require_once(dirname(__FILE__, 3) . '/config.php');

global $PAGE, $OUTPUT;

/** @var \moodle_page $PAGE */
$PAGE->set_context(context_system::instance());
$PAGE->set_url('/local/remoteauth/login.php');
$PAGE->set_pagelayout('login');
$PAGE->set_heading(get_string('login'));

$form = new \local_remoteauth\form\login();

/** @var core_renderer $OUTPUT */
echo $OUTPUT->header();

if ($form->is_cancelled()) {
    redirect(new moodle_url('/'));
} else if ($data = $form->get_data()) {
    $username = $data->username;
    $password = $data->password;

    $login = new \local_remoteauth\login($username, $password);
    $response = $login->request_login();

    if ($response->http_code == 200) {
        $userstatus = json_decode($response->response);
        if (!empty($userstatus) && $userstatus->status == 'ok') {
            $user = get_complete_user_data('username', $username);
            if (!empty($user)) {
                complete_user_login($user);
                redirect(new moodle_url('/'));
            }
        }
    }

    echo $OUTPUT->notification("Usuario o contraseña incorrectos.", 'error');
}

$form->display();

echo $OUTPUT->footer();
