<?php

namespace local_remoteauth;

use Firebase\JWT\JWT;

global $CFG;

include_once($CFG->libdir . '/filelib.php');


class login
{
    const DEFAULT_SECRET = 'moodleeabcsynctechnologies';
    const DEFAULT_REMOTE_AUTH_URL = 'https://n8n.app.e-abclearning.com/webhook/authmoodle';
    private $username;
    private $password;

    public function __construct($username, $password)
    {
        $this->username = $username;
        $this->password = $password;
    }

    public function request_login()
    {
        global $CFG;

        $data = array(
            'username' => $this->username,
            'password' => $this->password
        );

        if (empty($CFG->remoteauth_secret)) {
            $CFG->remoteauth_secret = self::DEFAULT_SECRET;
        }

        if (empty($CFG->remoteauth_url)) {
            $CFG->remoteauth_url = self::DEFAULT_REMOTE_AUTH_URL;
        }

        $jwt = JWT::encode($data, $CFG->remoteauth_secret, 'HS256');
        $curl = new \curl();

        $response = $curl->post(self::DEFAULT_REMOTE_AUTH_URL, array('code' => $jwt));

        $info = $curl->info;

        /** @var array $info */
        $http_code = $info['http_code'];

        return (object)[
            'response' => $response,
            'http_code' => $http_code
        ];
    }
}
