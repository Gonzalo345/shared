<?php

namespace local_remoteauth\form;

defined('MOODLE_INTERNAL') || die();

global $CFG;

require_once($CFG->libdir . '/formslib.php');

class login extends \moodleform
{
    public function definition()
    {
        $mform = $this->_form;
        $mform->addElement('text', 'username', get_string('username'));
        $mform->setType('username', PARAM_RAW);
        $mform->addElement('password', 'password', get_string('password'));
        $mform->setType('password', PARAM_RAW);
        $this->add_action_buttons(true, get_string('login'));
    }
}
