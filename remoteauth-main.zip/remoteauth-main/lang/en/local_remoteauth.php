<?php


$string['pluginname'] = 'Remote Authentication';