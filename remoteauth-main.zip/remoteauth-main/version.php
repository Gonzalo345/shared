<?php


defined('MOODLE_INTERNAL') || die();


$plugin->version   = 2024061400;
$plugin->requires  = 2021051700;
$plugin->component = 'local_remoteauth';
