# Remoteauth

Plugin de identificación de usuarios mediante autenticación remota. Los datos de usaurios se obtienen de un servidor remoto mediante una petición HTTP. Los usuarios y contraseñas se resguardan en un archivo Google Sheet al que puede acceder el servidor mediante una clave de API.

### Configuración

Se deben configurar dos variables en el config.php de moodle:

```php  

$CFG->remoteauth_url = 'http://url_remota/remoteauth.php';
$CFG->remoteauth_secret = 'codigolargoparavalidarlaclave';

```

Si no se configura nada, se tomarán los valores por defecto que se encuentran dentro del código del plugin.